package com.Hconfig;

import java.util.Properties;


import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EntityScan
@Configuration
@EnableTransactionManagement
@ComponentScan({"com"})
@PropertySource(value = {"classpath:application.properties"})
@EnableJpaRepositories


public class Configpurchasing {
	@Autowired
	private Environment environment;
	
	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionfactory= new LocalSessionFactoryBean();
		sessionfactory.setDataSource(datasource());
		sessionfactory.setPackagesToScan(new String [] {"com.model"});
		sessionfactory.setHibernateProperties(hibernateprop());
		return sessionfactory;
	
		
	}
	@Bean
	public DataSource datasource() {
		DriverManagerDataSource data = new DriverManagerDataSource();
		data.setDriverClassName(environment.getRequiredProperty("spring.datasource.driver-class-name"));
		data.setUrl(environment.getRequiredProperty("spring.datasource.url"));
		return data;
		
	}
	
	private Properties hibernateprop() {
		Properties prop= new Properties();
		prop.put("hibernate.dialect", environment.getRequiredProperty("spring.jpa.properties.hibernate.dialect"));
		prop.put("hibernate.show_sql", environment.getRequiredProperty("spring.jpa.show-sql"));
		prop.put("hibernate.connection.username", environment.getRequiredProperty("spring.datasource.username"));
		prop.put("hibernate.connection.password", environment.getRequiredProperty("spring.datasource.password"));
		prop.setProperty("hibernate.hbm2ddl.auto", environment.getRequiredProperty("spring.jpa.hibernate.ddl-auto"));
		return prop;	
	}
	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory s) {
		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(s);
		return txManager;
		
		
	}

}
