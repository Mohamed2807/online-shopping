package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Wish_list")
public class Wishlist {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="id")
	private int id;
	
	@Column(name ="productname")
	private String name;
	
	@Column(name ="total")
	private double total;
	
	@Column(name ="product_count")
	private int productcount;
	
	@Column(name ="buying_price")
	private double buyingprize;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public int getProductcount() {
		return productcount;
	}

	public void setProductcount(int productcount) {
		this.productcount = productcount;
	}

	public double getBuyingprize() {
		return buyingprize;
	}

	public void setBuyingprize(double buyingprize) {
		this.buyingprize = buyingprize;
	}

	@Override
	public String toString() {
		return "Wishlist [id=" + id + ", name=" + name + ", total=" + total + ", productcount=" + productcount
				+ ", buyingprize=" + buyingprize + "]";
	}
	
	

	
	
	

}
