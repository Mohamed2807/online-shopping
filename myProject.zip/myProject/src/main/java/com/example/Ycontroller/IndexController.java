package com.example.Ycontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;


import com.model.Product;
import com.model.User;

import com.service.ProductServiceimpl;
import com.service.UserServiceImpl;

@Controller
@ComponentScan("com")
public class IndexController {

	
	@Autowired
	private ProductServiceimpl proservice;
	
	@Autowired
	private UserServiceImpl userimpl;
	
	@RequestMapping(value ={"/home"}, method = RequestMethod.GET)
    public String index (ModelMap map) {	
		
	
	List<Product> pro= proservice.findAllProducts();
	map.addAttribute("dress",pro);
		
	
		return "index";
	}

   
		
	
	
	
	@RequestMapping(value ="/contact", method = RequestMethod.GET)
	public String contact(ModelMap map) {
		return "contact";
	}
	@RequestMapping(value ="/about", method = RequestMethod.GET)
	public String about(ModelMap map) {
		return "about";
}
	
	//.................................
	@RequestMapping(value ="/", method = RequestMethod.GET)
	public String signup(ModelMap map) {
		User user = new User();
		
		map.addAttribute("user",user);
		return "signup";
	}
	@RequestMapping(value ="/", method = RequestMethod.POST)
	public String savesignup(User user ,ModelMap map) {
		
		
			userimpl.saveuser(user);
			map.addAttribute("done",user.getFirstname()+ user.getLastname()+"has registered sucessfully");
			return"redirect:/login";}
		
	
	//..............................................................
	
	@RequestMapping(value ="login", method = RequestMethod.GET)
	public String login(ModelMap map) {
		User user = new User();
		
		map.addAttribute("user",user);
		return "login";
	}
	@RequestMapping(value ="/login", method = RequestMethod.POST)
	public String checkuser(User user ,ModelMap map) {
		User user1=new User();
		
		if(user1.getEmail()==user.getEmail() &&user1.getPassword()==user.getPassword()) {
		
			map.addAttribute("success","you logged in sucessfully");
			return "redirect:/home";
		}
				else {
			
			
			return"redirect:/home";}
		}
	
		
	 
	}

	
	
	
	















