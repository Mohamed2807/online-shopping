package com.example.Ycontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.model.Product;
import com.model.Wishlist;

import com.service.ProductServiceimpl;

import com.service.WishlistServiceimpl;
@Controller
@ComponentScan("com")
public class productcontroller {
	
	@Autowired
	private WishlistServiceimpl wishlistimpl;
	@Autowired
	private ProductServiceimpl productimpl;
	
	
	
	
	
	

	@RequestMapping(value ="/product", method = RequestMethod.GET)
	public String addproduct(ModelMap map) {
	Product product= new Product();
		map.addAttribute("product",product);
	return "addproduct";	
	}
	
	@PostMapping(value ={"/product"})
	public String saveproduct(Product product,ModelMap map,@RequestParam("myImage") MultipartFile  myImage) {
	System.out.println("i called .......");
		
		productimpl.saveproduct(product,  myImage);
	
		
		return  "redirect:/home"; 


}

	
	@RequestMapping(value ="/wishlist",method =RequestMethod.GET)
	public String showWishlist(ModelMap map) {
		List<Wishlist> wish =wishlistimpl.findWishlist();
		
		    map.addAttribute("wishlist",wish);
		return "wishlist";
	}
	
	@RequestMapping(value ="/wishlist-{id}",method =RequestMethod.GET)
	public String savewishlist(ModelMap map,@PathVariable("id")int id,Wishlist wish,Product product) {
		
          wishlistimpl.savewishlist(id);
	
		return "redirect:/home";
	
	}

	}