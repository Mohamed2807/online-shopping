package com.repo;



import com.model.User;

public interface UserRepository {

	public void saveuser(User user);
	User finduserbyemail(String email);
	
	
	public void update(User user);
}
