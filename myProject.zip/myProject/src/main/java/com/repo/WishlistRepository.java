package com.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Wishlist;


public interface WishlistRepository  {

//	public Wishlist findwishlistbyid(int id);
//	
	public void savewishlist(Wishlist wishlist);
	public List<Wishlist>findWishlist();
//	
	public boolean updatewishlist(Wishlist wishlist);
//	
	public boolean deletewishlist(Wishlist wishlist);
	
	//public List<Wishlist> findwishlistbywishid(int wishid );
	
	
	
	//Wishlist findwishlistbywishidandproductid(int wishid,int id);
	
	
	
}
