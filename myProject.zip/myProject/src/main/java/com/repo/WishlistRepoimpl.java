package com.repo;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Repository;

import com.model.Product;
import com.model.Wishlist;

@Repository
public class WishlistRepoimpl implements  WishlistRepository{
//
	@Autowired
	private SessionFactory factory;
//	
//	
//	@Override
//	public Wishlist findwishlistbyid(int id) {
//		// TODO Auto-generated method stub
//		Session ses=factory.getCurrentSession();
//		Wishlist wishlist =(Wishlist)ses.get(Wishlist.class, Integer.valueOf(id));
//		return wishlist;
//	}
//
//	@Override
//	public boolean savewishlist(Wishlist wishlist) {
//		// TODO Auto-generated method stub
//		Session ses=factory.getCurrentSession();
//		ses.save(wishlist);
//		return true;
//	}
//
	@Override
	public boolean updatewishlist(Wishlist wishlist) {
		Session ses=factory.getCurrentSession();
		ses.update(wishlist);
	return true;
	}

	@Override
	public boolean deletewishlist(Wishlist wishlist) {
		Session ses=factory.getCurrentSession();
		ses.delete(wishlist);
		return true;
	}
//
//	@Override
//	public List<Wishlist> findwishlistbywishid(int wishid) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public List<Wishlist> findWishlist() {
//		// TODO Auto-generated method stub
//	   Session session = factory.getCurrentSession();
//		CriteriaBuilder cb=session.getCriteriaBuilder();
//	    CriteriaQuery<Wishlist> cq=cb.createQuery(Wishlist.class);
//		Root<Wishlist> root=cq.from(Wishlist.class);
//		CriteriaQuery<Wishlist> all=cq.select(root);
//		TypedQuery<Wishlist> allQuery=session.createQuery(all);
//		return allQuery.getResultList();
//		
//	}
//
//	@Override
//	public Wishlist findwishlistbywishidandproductid(int wishid, int id) {
//		// TODO Auto-generated method stub
//		return null;
//	}

@Override
public void savewishlist(Wishlist wishlist) {
	// TODO Auto-generated method stub
	Session ses=factory.getCurrentSession();
	ses.save(wishlist);
	
}

@Override
public List<Wishlist> findWishlist() {
	Session session = factory.getCurrentSession();
	CriteriaBuilder cb = session.getCriteriaBuilder();
	CriteriaQuery<Wishlist> cq = cb.createQuery(Wishlist.class);
	Root<Wishlist> root = cq.from(Wishlist.class);
	CriteriaQuery<Wishlist> all = cq.select(root);
	TypedQuery<Wishlist> allQuery = session.createQuery(all);
	return allQuery.getResultList();
}




}
