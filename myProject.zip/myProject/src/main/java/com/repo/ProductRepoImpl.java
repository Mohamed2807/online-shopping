package com.repo;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{

	@Autowired
	private SessionFactory factory;
	@Override
	public void saveproduct(Product product) {
		// TODO Auto-generated method stub
		Session ses=factory.getCurrentSession();
		ses.save(product);
		
		
	}

	@Override
	public List<Product> findAllProducts() {
		Session session = factory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Product> cq = cb.createQuery(Product.class);
		Root<Product> root = cq.from(Product.class);
		CriteriaQuery<Product> all = cq.select(root);
		TypedQuery<Product> allQuery = session.createQuery(all);
		return allQuery.getResultList();
	}

	@Override
	public List<Product> findAllProductsForAdmin() {
		Session session = factory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Product> cq = cb.createQuery(Product.class);
		Root<Product> root = cq.from(Product.class);
		CriteriaQuery<Product> all = cq.select(root);
		TypedQuery<Product> allQuery = session.createQuery(all);
		return allQuery.getResultList();
	}

	

	@Override
	public void deleteProduct(Integer id) {
		// TODO Auto-generated method stub
		Session ses=factory.getCurrentSession();
		ses.delete(id);
		
	}

	@Override
	public void updateProduct(Product product) {
		Session ses=factory.getCurrentSession();
		ses.update(product);
		
	}

	@Override
	public List<Product> findProductBybrand(String brand) {
		Session session = factory.getCurrentSession();
		Criteria c = session.createCriteria(Product.class);
		c.add(Restrictions.eq("product.brand", brand));
		List<Product>products=c.list();
		return products;
	}

	@Override
	public Product findProductByIdForAdmin(int id) {
		Session session= factory.getCurrentSession();
		Product pro=session.get(Product.class, id);
		return pro;
	}

	@Override
	public List<Product> findProductBymaterial(String material) {
		Session session = factory.getCurrentSession();
		Criteria c = session.createCriteria(Product.class);
		c.add(Restrictions.eq("product.material", material));
		List<Product>products=c.list();
		return products;
	}

	@Override
	public Product findbyid(int id) {
		// TODO Auto-generated method stub
		Session session = factory.getCurrentSession();
		Product product = session.get(Product.class, Integer.valueOf(id));
		return product;
	}

	

	

}
