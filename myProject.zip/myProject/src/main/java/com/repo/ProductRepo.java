package com.repo;

import java.util.List;

import com.model.Product;

public interface ProductRepo {
	public void  saveproduct(Product product);
	
	 List<Product> findAllProducts();

	    List<Product> findAllProductsForAdmin();

	    

	    public void  deleteProduct(Integer id);

	    public void  updateProduct(Product product);

	    List<Product> findProductBymaterial(String material);
	    List<Product> findProductBybrand(String brand);

	    Product findProductByIdForAdmin(int id);
	    
	     public Product findbyid(int id); 
}
