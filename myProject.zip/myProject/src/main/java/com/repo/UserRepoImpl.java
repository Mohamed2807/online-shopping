package com.repo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.User;

@Repository
public class UserRepoImpl implements UserRepository {

	@Autowired
	private SessionFactory factory;

	@Override
	public void saveuser(User user) {
		Session ses= factory.getCurrentSession();
		ses.save(user);
		
	}

	@Override
	public User finduserbyemail(String email) {
		Session ses = factory.getCurrentSession();
		User user = (User)ses.get(User.class, Integer.valueOf(email));
		return user;
	}

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub
		Session ses= factory.getCurrentSession();
		ses.update(user);
		
		
	}
}
