package com.service;

import java.util.List;

import com.model.Product;
import com.model.Wishlist;

public interface WishlistService {

	
	public void savewishlist(int id);
	public List<Wishlist>findWishlist();
	
	public void updatewishlist(int id,Wishlist wishlist);
//	
	public boolean deletewishlist(Wishlist wishlist);
	public int gettotal(Product product);
	
}
