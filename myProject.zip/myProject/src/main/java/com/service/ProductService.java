package com.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.model.Product;

public interface ProductService {
	 List<Product> findAllProducts();
	 public void  saveproduct(Product product,MultipartFile file);
	    List<Product> findAllProductsForAdmin();

	    

	    public void  deleteProduct(Integer id);

	    public void  updateProduct(Product product);

	    List<Product> findProductBymaterial(String material);
	    List<Product> findProductBybrand(String brand);

	    Product findProductByIdForAdmin(int id);
	

}
