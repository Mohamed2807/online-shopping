package com.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.User;
import com.repo.UserRepoImpl;
import com.repo.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService{
	
	
	@Autowired
	private UserRepository userrepo;



	@Override
	public void saveuser(User user) {
		// TODO Auto-generated method stub
		userrepo.saveuser(user);
		
		
		System.out.println("saved sucessfully");
		
	}

	@Override
	public String finduserbyemail(String email) {
		// TODO Auto-generated method stub
		User user = userrepo.finduserbyemail(email);
		if(user!=null) {
		System.out.println("search done !!");
		return"exists";
		}
		else {
		return "new";
		}
	
	}

	@Override
	public String update(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
