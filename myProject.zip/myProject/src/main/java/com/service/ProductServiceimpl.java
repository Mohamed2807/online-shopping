package com.service;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.model.Product;
import com.repo.ProductRepo;
import com.repo.ProductRepoImpl;

@Service
@Transactional
public class ProductServiceimpl implements ProductService {

	@Autowired
	private ProductRepoImpl prorepo;

	

	@Override
	public List<Product> findAllProducts() {
		 List<Product> products = new ArrayList<>();
		 prorepo.findAllProducts().forEach(products::add);
		  return products;
	}

	@Override
	public List<Product> findAllProductsForAdmin() {
		 List<Product> products = new ArrayList<>();
	        prorepo.findAllProductsForAdmin().forEach(products::add);
	        return products;
	}


	@Override
	public List<Product> findProductBybrand(String brand) {
		 List<Product> products = new ArrayList<>();
	        List<Product> productsCopy = new ArrayList<>();
	        prorepo.findProductBybrand(brand).forEach(products::add);
	        productsCopy.addAll(products);
	        for (Product p : products) {
	           
	        }
	        return productsCopy;
	    }

	

	@Override
	public Product findProductByIdForAdmin(int id) {
		// TODO Auto-generated method stub
		  Product product = prorepo.findProductByIdForAdmin(id);
	        return product;
	}

	

	@Override
	public List<Product> findProductBymaterial(String material) {
		 List<Product> products = new ArrayList<>();
	        List<Product> productsCopy = new ArrayList<>();
	        prorepo.findProductBymaterial(material).forEach(products::add);
	        productsCopy.addAll(products);
	        for (Product p : products) {
	           
	        }
	        return productsCopy;
	    }

	@Override
	public void deleteProduct(Integer id) {
		// TODO Auto-generated method stub
		prorepo.deleteProduct(id);
		
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		prorepo.updateProduct(product);
		
	}

	@Override
	public void saveproduct(Product product,MultipartFile image) {
		// TODO Auto-generated method stub
		
		String imgfile=StringUtils.cleanPath(image.getOriginalFilename());
		
		
		if(imgfile.contains("..")) {
			System.out.println("not a valid file");
		}
		
		try {
			product.setMyimageobj(Base64.getEncoder().encodeToString(image.getBytes()));
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		prorepo.saveproduct(product);
	}
	}

	


