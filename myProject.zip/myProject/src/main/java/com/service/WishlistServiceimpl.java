package com.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Product;

import com.model.Wishlist;
import com.repo.ProductRepoImpl;
import com.repo.WishlistRepoimpl;


@Service
@Transactional
public class WishlistServiceimpl implements WishlistService{

	
	
	
	@Autowired
	private ProductRepoImpl prorepo;
	
	@Autowired
	private WishlistRepoimpl wishrepo;
	
	
    public WishlistServiceimpl(WishlistRepoimpl wishrepo) {
	this.wishrepo=wishrepo;
	// TODO Auto-generated constructor stub
}


	@Override
	public void savewishlist(int id) {
		// TODO Auto-generated method s
		Product product=prorepo.findbyid(id);
		Wishlist wishlist=new Wishlist();
	
		wishlist.setName(product.getName());
		wishlist.setBuyingprize(product.getUnitprize());
		wishlist.setProductcount(1);
		wishlist.setTotal(product.getUnitprize());
	
		
		
	
		
		
	
	
		wishrepo.savewishlist(wishlist);
//		System.out.println("its working");
//		wishlist.setActive(false);
//		wishlist.setCid(wishlist.getCid()+1);

		
	}
	@Override
	public void updatewishlist(int id,Wishlist wishlist) {
		// TODO Auto-generated method stub
		
//		Product product=prorepo.findbyid(id);
//		int i=wishlist.getProductcount();
//		i=i+1;
//		wishlist.setName(product.getName());
//		wishlist.setBuyingprize(product.getUnitprize());
//		wishlist.setTotal(wishlist.getBuyingprize()*i);
//		wishlist.setActive(1);
//		wishlist.setCid(product.getId());
////		int i=1;i++;
//		
//		wishrepo.updatewishlist(wishlist);
//		
		
	}


	@Override
	public List<Wishlist> findWishlist() {
		// TODO Auto-generated method stub
		List<Wishlist> wish =new ArrayList<>();
		wishrepo.findWishlist().forEach(wish::add);
		
		return wish;
	}





	@Override
	public boolean deletewishlist(Wishlist wishlist) {
		// TODO Auto-generated method stub
		wishrepo.deletewishlist(wishlist);
		return true;
	}


	@Override
	public int gettotal(Product product) {
		// TODO Auto-generated method stub
		return 0;
	}


	
	

}
