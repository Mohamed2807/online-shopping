package com.service;

import com.model.User;

public interface UserService {

	public void saveuser(User user);
	String finduserbyemail(String email);
	public String update(User user);
}
